import java.io.PrintWriter;
import java.util.*;
import java.io.File;

public class task1
{
  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return null;
    }

    ArrayList<String> result = new ArrayList<String>();
    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    
    input_file.close();
    return result;
  } 


  public static String[][] read_spreadsheet(String filename)
  {
    ArrayList<String> lines = read_file(filename);
    
    int rows = lines.size();

    // The row below creates an array of length "rows", that stores
    // objects of type String[]. Those objects are initialized to null.
    String[][] result = new String[rows][]; 
            
    for (int i = 0; i < lines.size(); i++)
    {
      String line = lines.get(i);
      String [] values = line.split(",");
      result[i] = values;
    }

    return result;
  }  
  
  
  public static void print_player_info(String[][] data, String player)
  {
    player = player.toLowerCase();
    for (int i = 1; i < data.length; i++)
    {
      // get value at the specified column of row i.
      String name = data[i][0].toLowerCase();
      if (name.indexOf(player) >= 0)
      {
        System.out.printf("\n");
        for (int j = 0; j < data[i].length; j++)
        {
          System.out.printf("%20s: %s\n", data[0][j], data[i][j]);
        }
        System.out.printf("\n");
      }
    }
  }
  
  
  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);
    String[][] data = read_spreadsheet("nba.txt");
    while (true)
    {
      System.out.printf("\nEnter part of a player's name (or q to quit): ");
      String player = in.next();
      if (player.equals("q"))
      {
        System.out.printf("Exiting...\n");
        System.exit(0);
      }
      print_player_info(data, player);
    }
      
  }
}