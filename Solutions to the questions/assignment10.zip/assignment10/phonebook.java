import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.PrintWriter;

public class phonebook
{
  // returns a phonebook:
  // either reads it from the phonebook.txt file, if the file exists, 
  // or returns an empty array.
  public static String[][] read_phonebook()
  {
    String filename = "phonebook.txt";
    String[][] data = read_spreadsheet(filename);
    return data;
  }
  
  
  public static void save_phonebook(String[][] data, String new_name, String new_number)
  {
    String filename = "phonebook.txt";
    PrintWriter out = null;
    try
    {
      out = new PrintWriter(filename);
    }
    catch (Exception e)
    {
      System.out.printf("Error: failed to open file %s.\n", filename);
    }
    for (int i = 0; i < data.length; i++)
    {
      out.printf("%s,%s\r\n", data[i][0], data[i][1]);
    }
    out.printf("%s,%s\r\n", new_name, new_number);
    out.close();
  } 
    

  public static void print_spreadsheet(String[][] data)
  {
    System.out.printf("\n");
    for (int i = 0; i < data.length; i++)
    {
      System.out.printf("%4d: %20s, %s", i, data[i][0], data[i][1]);
      System.out.printf("\n");
    }
    System.out.printf("\n");
  }
  
  
  public static void search_data(String[][] data)
  {
    System.out.printf("\nEnter part of the name: ");
    Scanner in = new Scanner(System.in);
    String entry = in.nextLine();
    entry = entry.toLowerCase();
    
    for (int i = 0; i < data.length; i++)
    {
      String name = data[i][0];
      String name2 = name.toLowerCase();
      if (name2.indexOf(entry) != -1)
      {
        String number = data[i][1];
        System.out.printf("%20s: %s\n", name, number);
      }
    }
  }
  
  
  public static String[][] read_spreadsheet(String filename)
  {
    ArrayList<String> lines = read_file("phonebook.txt");
    if (lines == null)
    {
      return null;
    }

    int rows = lines.size();
    String[][] result = new String[rows][];

    for (int i = 0; i < rows; i++)
    {
      String line = lines.get(i);
      String[] values = line.split(",");
      result[i] = values;
    }

    return result;
  } 
  
  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    ArrayList<String> result = new ArrayList<String>();

    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return result;
    }

    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    
    input_file.close();
    return result;
  }

  public static String[][] input_new_entry(String[][] data)
  {
    Scanner in = new Scanner(System.in);
    
    System.out.printf("\nEnter a name: ");
    String name = in.nextLine();
    System.out.printf("\nEnter a number: ");
    String number = in.nextLine();
    save_phonebook(data, name, number);
    data = read_phonebook();
    return data;
  }  
  
  
  public static String[][] process_option(String[][] data, String option)
  {
    if (option.equals("1"))
    {
      print_spreadsheet(data);
    }
    else if (option.equals("2"))
    {
      data = input_new_entry(data);
    }
    else if (option.equals("3"))
    {
      search_data(data);
    }
    else if (option.equals("q"))
    {
      System.exit(0);
    }
    else
    {
      System.out.printf("Unrecognized option %s.\n", option);
    }
    
    return data;
  }
  
  public static String ask_option()
  {
    Scanner in = new Scanner(System.in);
    
    System.out.printf("\n1: Print phonebook.\n");
    System.out.printf("2: Input a new entry.\n");
    System.out.printf("3: Search by name.\n");
    System.out.printf("q: Quit program.\n");
    System.out.printf("Please enter an option: ");
    String option = in.next();
    return option;
  }

  
  public static void main(String[] args)
  {
    String[][] data = read_phonebook();
    print_spreadsheet(data);

    while(true)
    {
      String option = ask_option();
      data = process_option(data, option);
    }
  }
  
}
