import java.util.Scanner;

public class task4
{
  public static int count_words(String text)
  {
    int counter = 0;
    char previous = ' ';
    for (int i = 0; i < text.length(); i++)
    {
      char c = text.charAt(i);
      if ((c != ' ') && (previous == ' '))
      {
        counter++;
      }
      previous = c;
    }
    
    return counter;
  }
  
  
  
  public static void main(String[] args) 
  {
    Scanner in = new Scanner(System.in);
    
    while (true)
    {
      System.out.printf("Enter some text, or q to quit: ");
      String text = in.nextLine();
      if (text.equals("q"))
      {
        System.out.printf("Exiting...\n");
        System.exit(0);
      }
      int result = count_words(text);
      System.out.printf("Counted %d words.\n\n", result);
    }
  }
}
