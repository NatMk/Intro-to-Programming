import java.util.Scanner;

public class task3
{
  public static void print_coded(String text, String sources, String targets)
  {
    for (int i = 0; i < text.length(); i++)
    {
      char c = text.charAt(i);
      int index = sources.indexOf(c);
      if (index >= 0)
      {
        System.out.printf("%c", targets.charAt(index));
      }
      else
      {
        System.out.printf("%c", c);
      }
    }
  }
  
  
  
  public static void main(String[] args) 
  {
    Scanner in = new Scanner(System.in);
    
    String sources = "abcdefghijklmnopqrstuvwxyz";
    String targets = "bcdefghijklmnopqrstuvwxyza";
    
    while (true)
    {
      System.out.printf("Enter some word, or q to quit: ");
      String word = in.next();
      if (word.equals("q"))
      {
        System.out.printf("Exiting...\n");
        System.exit(0);
      }
      print_coded(word, sources, targets);
      System.out.printf("\n\n");
    }
  }
}
