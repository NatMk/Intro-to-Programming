import java.util.Scanner;

public class task6
{
  public static int year_days(int year)
  {
    if (is_leap_year(year))
    {
      return 366;
    }
    return 365;
  }
  
  public static int month_days(int year, int month)
  {
    if ((month == 1) || (month == 3) || (month == 5) || (month == 7) ||
        (month == 8) || (month == 10) || (month == 12))
    {
      return 31;
    }
    if ((month == 4) || (month == 6) || (month == 9) || (month == 11))
    {
      return 30;
    }
    if (is_leap_year(year))
    {
      return 29;
    }
    return 28;
  }
  
  public static boolean is_leap_year(int year)
  {
    if (year % 100 == 0)
    {
      if (year % 400 == 0)
      {
        return true;
      } 
      else
      {
        return false;
      }
    } 
    else
    {
      if (year % 4 == 0)
      {
        return true;
      } 
      else
      {
        return false;
      }
    }
  }
  
  
  public static int user_integer(String message)
  {
    Scanner in = new Scanner(System.in);
    int result;
    while (true)
    {
      System.out.printf(message);
      String s = in.next();
      if (s.equals("q"))
      {
        System.out.printf("Exiting...\n");
        System.exit(0);
      }
      
      try
      {
        result = Integer.parseInt(s);
      } 
      catch (Exception e)
      {
        System.out.printf("%s is not a valid number, try again.\n\n", s);
        continue;
      }
      
      if (result <= 0)
      {
        System.out.printf("%s is <= 0, try again.\n\n", s);
        continue;
      }
      return result;
    }
  }
  
  
  public static void main(String[] args) 
  {
    Scanner in = new Scanner(System.in);
    
    while (true)
    {
      int year = user_integer("Enter a year (must be > 0): ");      
      int result = year_days(year);
      System.out.printf("Year %d has %d days.\n\n", year, result);
      
      int month = user_integer("Enter a month(must be between 1 and 12): ");
      if (month > 12)
      {
        System.out.printf("Invalid month.\n\n");
        continue;
      }
      int result2 = month_days(year, month);
      System.out.printf("Month %d, %d has %d days.\n\n", month, year, result2);
      
      
    }
  }
}
