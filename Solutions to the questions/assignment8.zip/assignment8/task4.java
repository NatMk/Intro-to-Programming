import java.util.*;

public class task4
{
  public static void insert_before_larger(ArrayList<Integer> A, int x)
  {
    for (int i = 0; i < A.size(); i++)
    {
      if (x < A.get(i))
      {
        A.add(i, x);
        return;
      }
    }
    A.add(x);
  }
    
  public static void main(String[] args)
  {
    ArrayList<Integer> a = new ArrayList<Integer>();
    
    insert_before_larger(a, 40);
    System.out.println(a);
    insert_before_larger(a, 10);
    System.out.println(a);
    insert_before_larger(a, 50);
    System.out.println(a);
    insert_before_larger(a, 20);
    System.out.println(a);
    insert_before_larger(a, 30);
    System.out.println(a);
  }
}