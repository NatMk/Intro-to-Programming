import java.util.*;

public class task7
{
  public static int find_minimum_length(ArrayList<String> A)
  {
    if (A.size() == 0)
    {
      return -1;
    }
    String minimum = A.get(0);
    int position = 0;
    for (int i = 1; i < A.size(); i++)
    {
      String current = A.get(i);
      if (current.length() < minimum.length())
      {
        minimum = current;
        position = i;
      }
    }
    
    return position;
  }
    

  public static void remove_minimum_length(ArrayList<String> A)
  {
    if (A.size() == 0)
    {
      return;
    }
    int position = find_minimum_length(A);
    A.remove(position);
  }

  public static void main(String[] args)
  {
    ArrayList<String> a = new ArrayList<String>();
    
    a.add("whale");
    a.add("cat");
    a.add("elephant");
    a.add("donkey");
    a.add("goat");

    System.out.println(a);
    int position = find_minimum_length(a);
    System.out.printf("minimum position = %d\n\n", position);

    remove_minimum_length(a);
    System.out.println(a);
    position = find_minimum_length(a);
    System.out.printf("minimum position = %d\n\n", position);

    remove_minimum_length(a);
    System.out.println(a);
    position = find_minimum_length(a);
    System.out.printf("minimum position = %d\n\n", position);

    remove_minimum_length(a);
    System.out.println(a);
    position = find_minimum_length(a);
    System.out.printf("minimum position = %d\n\n", position);

    remove_minimum_length(a);
    System.out.println(a);
    position = find_minimum_length(a);
    System.out.printf("minimum position = %d\n\n", position);

    remove_minimum_length(a);
    System.out.println(a);
    position = find_minimum_length(a);
    System.out.printf("minimum position = %d\n\n", position);
 }
}
