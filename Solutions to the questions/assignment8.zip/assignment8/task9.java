import java.util.*;

public class task9
{
  public static ArrayList<String> sort_by_length(ArrayList<String> A)
  {
    ArrayList<String> result = new ArrayList<String>();
    for (int i = 0; i < A.size(); i++)
    {
      String current = A.get(i);
      insert_before_longer(result, current);
    }
    return result;
  }
    
  
  public static void insert_before_longer(ArrayList<String> A, String x)
  {
    for (int i = 0; i < A.size(); i++)
    {
      String current = A.get(i);
      if (x.length() < current.length())
      {
        A.add(i, x);
        return;
      }
    }
    A.add(x);
  }
    

  public static void main(String[] args)
  {
    ArrayList<String> a = new ArrayList<String>();
    
    a.add("whale");
    a.add("cat");
    a.add("elephant");
    a.add("donkey");
    a.add("goat");

    ArrayList<String> result = sort_by_length(a);
    System.out.printf("Input:  ");
    System.out.println(a);
    System.out.printf("Output: ");
    System.out.println(result);  
  }
}