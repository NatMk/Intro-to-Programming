import java.util.*;

public class task5
{
  public static ArrayList<Integer> sort_array(ArrayList<Integer> A)
  {
    ArrayList<Integer> result = new ArrayList<Integer>();
    for (int i = 0; i < A.size(); i++)
    {
      int current = A.get(i);
      insert_before_larger(result, current);
    }
    return result;
  }
    
    public static void insert_before_larger(ArrayList<Integer> A, int x)
  {
    for (int i = 0; i < A.size(); i++)
    {
      if (x < A.get(i))
      {
        A.add(i, x);
        return;
      }
    }
    A.add(x);
  }
    

  public static void main(String[] args)
  {
    ArrayList<Integer> a = new ArrayList<Integer>();
    
    a.add(40);
    a.add(10);
    a.add(50);
    a.add(20);
    a.add(30);

    ArrayList<Integer> result = sort_array(a);
    System.out.printf("Input:  ");
    System.out.println(a);
    System.out.printf("Output: ");
    System.out.println(result);
  }
}