import java.util.*;

public class task8
{
  public static void insert_before_longer(ArrayList<String> A, String x)
  {
    for (int i = 0; i < A.size(); i++)
    {
      String current = A.get(i);
      if (x.length() < current.length())
      {
        A.add(i, x);
        return;
      }
    }
    A.add(x);
  }
    
  public static void main(String[] args)
  {
    ArrayList<String> a = new ArrayList<String>();
    
    insert_before_longer(a, "whale");
    System.out.println(a);
    insert_before_longer(a, "cat");
    System.out.println(a);
    insert_before_longer(a, "elephant");
    System.out.println(a);
    insert_before_longer(a, "donkey");
    System.out.println(a);
    insert_before_longer(a, "goat");
    System.out.println(a);
  }
}
