import java.util.Scanner;

public class task8
{
  public static void main(String[] args) 
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Please enter the name of a month: ");
    String month = in.next();
    
    if (month.equals("January") || month.equals("january"))
    {
      System.out.printf("January is the first month.\n");
    }
    else if (month.equals("February") || month.equals("february"))
    {
      System.out.printf("February is the second month.\n");
    }
    else if (month.equals("March") || month.equals("march"))
    {
      System.out.printf("March is the third month.\n");
    }
    else if (month.equals("April") || month.equals("april"))
    {
      System.out.printf("April is the fourth month.\n");
    }
    else if (month.equals("May") || month.equals("may"))
    {
      System.out.printf("May is the fifth month.\n");
    }
    else if (month.equals("June") || month.equals("june"))
    {
      System.out.printf("June is the sixth month.\n");
    }
    else if (month.equals("July") || month.equals("july"))
    {
      System.out.printf("July is the seventh month.\n");
    }
    else if (month.equals("August") || month.equals("august"))
    {
      System.out.printf("August is the eigth month.\n");
    }
    else if (month.equals("September") || month.equals("september"))
    {
      System.out.printf("September is the ninth month.\n");
    }
    else if (month.equals("October") || month.equals("october"))
    {
      System.out.printf("October is the tenth month.\n");
    }
    else if (month.equals("November") || month.equals("november"))
    {
      System.out.printf("November is the eleventh month.\n");
    }
    else if (month.equals("December") || month.equals("december"))
    {
      System.out.printf("December is the twelfth month.\n");
    }
    else
    {
      System.out.printf("invalid month\n");
    }
  }
}
