import java.util.Scanner;

public class task11
{
  public static void main(String[] args) 
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Please enter a word: ");
    String input = in.next();
    
    String vowels = "aeiouAEIOU";
    String consonants = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ";
    
    String initial = input.substring(0,1);
    
    if (vowels.indexOf(initial) != -1)
    {
      System.out.printf("%s starts with a vowel.\n", input);
    }
    else if (consonants.indexOf(initial) != -1)
    {
      System.out.printf("%s starts with a consonant.\n", input);
    }
    else
    {
      System.out.printf("%s starts with neither a vowel nor a consonant.\n", input);
    }
  }
}
