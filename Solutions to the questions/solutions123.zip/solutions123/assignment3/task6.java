import java.util.Scanner;

public class task6 
{
  public static void main(String[] args) 
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Please specify the number of seconds (between 1 and 86400): ");
    int input = in.nextInt();
    
    if ((input < 1) || (input > 86400))
    {
      System.out.printf("Invalid number of seconds, must be between 1 and 86400.\n");
      System.exit(0);
    }
    
    int hours = input / 3600;
    int leftover = input % 3600;
    int minutes = leftover / 60;
    int seconds = leftover % 60;
    
    System.out.printf("%d seconds correspond to %d hours, %d minutes, and %d seconds.\n",
                      input, hours, minutes, seconds);
  }
}
