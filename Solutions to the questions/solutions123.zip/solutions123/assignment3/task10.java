import java.util.Scanner;

public class task10
{
  public static void main(String[] args) 
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Please enter an integer: ");
    int input = in.nextInt();
    
    if ((input % 2 == 0) && (input % 3 == 0))
    {
      System.out.printf("The number is even and divisible by 3.\n", input);
    }
    else if ((input % 2 == 0) && (input % 3 != 0))
    {
      System.out.printf("The number is even and not divisible by 3.\n", input);
    }
    else if ((input % 2 != 0) && (input % 3 == 0))
    {
      System.out.printf("The number is odd and divisible by 3.\n", input);
    }
    else
    {
      System.out.printf("The number is odd and not divisible by 3.\n", input);
    }
  }
}
