import java.util.Scanner;

public class task6
{
  public static void main(String[] args) 
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Enter the rectangle length: ");
    double length = in.nextDouble();
    System.out.printf("Enter the rectangle width: ");
    double width = in.nextDouble();
    double area = length * width;
    double perimeter = 2 * (length + width);
    System.out.printf("The area of the rectangle is %f.\n", area);
    System.out.printf("The perimeter of the rectangle is %f.\n", perimeter);
  }
}