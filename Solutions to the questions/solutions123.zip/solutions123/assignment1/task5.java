import java.util.Scanner;

public class task5
{
  public static void main(String[] args) 
  {
    double length = 5.0;
    double width = 4.0;
    double area = length * width;
    double perimeter = 2 * (length + width);
    System.out.printf("The area of the rectangle is %f.\n", area);
    System.out.printf("The perimeter of the rectangle is %f.\n", perimeter);
  }
}