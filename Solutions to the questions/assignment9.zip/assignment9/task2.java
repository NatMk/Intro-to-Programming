import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;

public class task2
{
  public static void count_vowels(String input_file)
  {
    ArrayList<String> lines = read_file(input_file);
    String letters = "aeiou";
    int[] counters = new int[letters.length()];
    for (int i = 0; i < lines.size(); i++)
    {
      String line = lines.get(i).toLowerCase();
      for (int j = 0; j < line.length(); j++)
      {
        char c = line.charAt(j);
        int index = letters.indexOf(c);
        if (index > -1)
        {
          counters[index]++;
        }
      }
    }
    
    for (int i = 0; i < letters.length(); i++)
    {
      char c = letters.charAt(i);
      int counter = counters[i];
      System.out.printf("%c: %d times\n", c, counter);
    }
  }
          

  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return null;
    }

    ArrayList<String> result = new ArrayList<String>();
    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    
    input_file.close();
    return result;
  }

  public static void main(String[] args)
  {
    count_vowels("in2.txt");
  }
}  
