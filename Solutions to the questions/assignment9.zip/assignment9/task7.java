import java.util.*;
import java.io.File;

public class task7
{
  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return null;
    }

    ArrayList<String> result = new ArrayList<String>();
    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    
    input_file.close();
    return result;
  } 


  public static int get_month(String date)
  {
    String[] split1 = date.split(" ");
    String second = split1[1];
    String[] split2 = second.split("/");
    String month_string = split2[0];
    int result = Integer.parseInt(month_string);
    return result;
  }
  
  
  public static String column_name(String filename, int column)
  {
    ArrayList<String> lines = read_file(filename);
    String line = lines.get(0);
    String[] names = line.split(",");
    if ((column < 0) || (names.length <= column))
    {
      return null;
    }
    return names[column];
  }
  
  public static double monthly_average(String filename, int column, int month)
  {
    ArrayList<String> lines = read_file(filename);
    double result = 0;
    double count = 0;
    for (int i = 1; i < lines.size(); i++)
    {    
      String line = lines.get(i);
      String[] columns = line.split(",");

      String date = columns[0];
      int line_month = get_month(date);
      if (line_month != month)
      {
        continue;
      }
      
      String column_text = columns[column];
      double value = Double.parseDouble(column_text);
      result = result + value;
      count = count+1;
    }
    if (count == 0)
    {
      return -1;
    }
    return result/count;
  }
  
  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);
    while (true)
    {
      System.out.printf("Enter a filename (or q to quit): ");
      String filename = in.next();
      if (filename.equals("q"))
      {
        System.out.printf("Exiting...\n");
        System.exit(0);
      }
      System.out.printf("Enter a column: ");
      int column = in.nextInt();
      String name = column_name(filename, column);
      
      System.out.printf("Enter a month: ");
      int month = in.nextInt();
      
      double average = monthly_average(filename, column, month);
      if (average == -1.00)
      {
        System.out.printf("In file %s, there is no data for %s for month %d.\n\n",
                          filename, name, month);
      }
      else
      {
        System.out.printf("In file %s, the average %s for month %d is %.2f.\n\n",
                          filename, name, month, average);
      }
    }
  }
}