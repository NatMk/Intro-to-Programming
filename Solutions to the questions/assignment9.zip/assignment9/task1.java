import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.PrintWriter;

public class task1
{
  public static void check_primes(String input_file, String output_file)
  {
    ArrayList<String> lines = read_file(input_file);
    PrintWriter out = null;
    try
    {
      out = new PrintWriter(output_file);
    }
    catch (Exception e)
    {
      System.out.printf("Error: failed to open file %s.\n", output_file);
      return;
    }
    for (int i = 0; i < lines.size(); i++)
    {
      String line = lines.get(i);
      int number;
      try
      {
        number = Integer.parseInt(line);
      }
      catch (Exception e)
      {
        System.out.printf("Error: line %s is not a number.\n", line);
        return;
      }
      if (is_prime(number))
      {
        out.printf("%d is prime\r\n", number);
      }
      else
      {
        out.printf("%d is not prime\r\n", number);
      }
    }
    out.close();
  }
          

  public static boolean is_prime(int N)
  {
    for (int i = 2; i < N; i++)
    {
      if (N % i == 0)
      {
        return false;
      }
    }
    return true;
  }
 
  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return null;
    }

    ArrayList<String> result = new ArrayList<String>();
    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    
    input_file.close();
    return result;
  }

  public static void main(String[] args)
  {
    check_primes("in1.txt", "out1.txt");
    System.out.printf("Exiting...\n");
  }
}  
