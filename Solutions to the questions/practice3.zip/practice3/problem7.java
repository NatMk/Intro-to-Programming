import java.util.*;
import java.io.File;

public class problem7
{
  public static String[][] read_spreadsheet(String filename)
  {
    ArrayList<String> lines = read_file(filename);

    int rows = lines.size();

    // The row below creates an array of length "rows", that stores
    // objects of type String[]. Those objects are initialized to null.
    String[][] result = new String[rows][]; 

    for (int i = 0; i < lines.size(); i++)
    {
      String line = lines.get(i);
      String [] values = line.split(",");
      result[i] = values;
    }

    return result;
  } 
  
  
  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    ArrayList<String> result = new ArrayList<String>();

    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return result;
    }

    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    
    input_file.close();
    return result;
  }  
  
  
  public static int[] max_length_position(String filename)
  {
    String[][] values = read_spreadsheet(filename);
    int max_length = 0;
    int max_row = 0;
    int max_col = 0;
    for (int row = 0; row < values.length; row++)
    {
      String[] line_values = values[row];
      for (int col = 0; col < line_values.length; col++)
      {
        int len = line_values[col].length();
        if (len > max_length)
        {
          max_length = len;
          max_row = row;
          max_col = col;
        }
      }
    }
     
    int[] result = new int[2];
    result[0] = max_row;
    result[1] = max_col;
    return result;
  }


  public static void main(String[] args)
  {
    int[] result = max_length_position("file2.txt");
    System.out.printf("%d, %d\n", result[0], result[1]);
  }
}

