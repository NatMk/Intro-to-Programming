/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author athitsos
 */
public class problem1b
{
  public static int a_between_stars(String s)
  {
    int first_star = -1;
    for (int i = 0; i < s.length(); i++)
    {
      if (s.charAt(i) == '*')
      {
        first_star = i;
        break;
      }
    }
    
    if (first_star == -1)
    {
      return 0;
    }
    
    int second_star = -1;
    for (int i = first_star + 1; i < s.length(); i++)
    {
      if (s.charAt(i) == '*')
      {
        second_star = i;
        break;
      }
    }
    
    int limit;
    if (second_star == -1)
    {
      limit = s.length();
    }
    else
    {
      limit = second_star;
    }
    
    
    int counter = 0;
    for (int i = first_star + 1; i < limit; i++)
    {
      if (s.charAt(i) == 'a')
      {
        counter++;
      }
    }
    
    return counter;
  }
  
  public static void main(String[] arg)
  {
    System.out.printf("a_between_stars(\"ab*ab*ab\") = %d\n", 
                      a_between_stars("ab*ab*ab"));
    System.out.printf("a_between_stars(\"a cat*chases after its tail\") = %d\n", 
                      a_between_stars("a cat*chases after its tail"));
    System.out.printf("a_between_stars(\"a cat*chases after*its tail\") = %d\n", 
                      a_between_stars("a cat*chases after*its tail"));
  }
}
