public class problem10
{
  public static void print_2d_array(int[][] numbers)
  {
    for (int i = 0; i < numbers.length; i++)
    {
      for (int j = 0; j < numbers[i].length; j++)
      {
        System.out.printf("%3d,", numbers[i][j]);
      }
      System.out.printf("\n");
    }
  }
  
  public static int[][] subarray_sums(int[] array)
  {
    int len = array.length;
    int[][] result = new int[len][len];
    for (int i = 0; i < len; i++)
    {
      for (int j = 0; j < len; j++)
      {
        result[i][j] = 0;
        for (int k = i; k <= j; k++)
        {
          result[i][j] += array[k];
        }
      }
    }
    
    return result;
  }
  
  public static void main(String[] args)
  {
    int[] a1 = {7, 3, 8, 1, 2};
    print_2d_array(subarray_sums(a1));
  }
}

