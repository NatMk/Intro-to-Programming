import java.util.*;
import java.io.File;

public class problem2
{
  public static void print_towns(String filename)
  {
    ArrayList<String> lines = read_file(filename);
    for (int i = 0; i < lines.size(); i++)
    {
      String line = lines.get(i);
      String[] fields = line.split("[0123456789]");
      String town = fields[1];
      System.out.printf("%s\n", town);
    }
  }
  
  
  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    ArrayList<String> result = new ArrayList<String>();

    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return result;
    }

    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    
    input_file.close();
    return result;
  }  
  
  
    public static void main(String[] args)
  {
    print_towns("towns.txt");
  }
}
