public class problem4
{
  public static boolean check_squares(int[] a)
  {
    boolean result = false;
    
    for (int i = 0; i < a.length; i++)
    {
      int n = a[i];
      for (int j = 0; j < a.length; j++)
      {
        if (n*n == a[j])
        {
          return true;
        }
      }
    }

    return false;
  }

          
  public static void main(String[] args)
  {
    boolean result;
    
    int[] a1 = {1, 1, 1, 2};
    result = check_squares(a1);
    System.out.printf("check_squares(a1) = %b\n", result);

    int[] a2 = {20, 10, 20, 20, 20};
    result = check_squares(a2);
    System.out.printf("check_squares(a1) = %b\n", result);

    int[] a3 = {20, 100, 2, 10, 20, 20, 20};
    result = check_squares(a3);
    System.out.printf("check_squares(a1) = %b\n", result);

  }
}
