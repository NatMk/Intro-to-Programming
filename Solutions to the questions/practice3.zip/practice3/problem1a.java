/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author athitsos
 */
public class problem1a
{
  public static int a_after_star(String s)
  {
    int first_star = -1;
    for (int i = 0; i < s.length(); i++)
    {
      if (s.charAt(i) == '*')
      {
        first_star = i;
        break;
      }
    }
    
    if (first_star == -1)
    {
      return 0;
    }
    
    int counter = 0;
    for (int i = first_star + 1; i < s.length(); i++)
    {
      if (s.charAt(i) == 'a')
      {
        counter++;
      }
    }
    
    return counter;
  }
  
  public static void main(String[] arg)
  {
    System.out.printf("a_after_star(\"ab*ab*ab\") = %d\n", 
                      a_after_star("ab*ab*ab"));
    System.out.printf("a_after_star(\"a cat*chases after its tail\") = %d\n", 
                      a_after_star("a cat*chases after its tail"));
    System.out.printf("a_after_star(\"a cat*chases after*its tail\") = %d\n", 
                      a_after_star("a cat*chases after*its tail"));
  }
}
