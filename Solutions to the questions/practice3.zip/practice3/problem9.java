public class problem9
{
  public static void print_2d_array(int[][] numbers)
  {
    for (int i = 0; i < numbers.length; i++)
    {
      for (int j = 0; j < numbers[i].length; j++)
      {
        System.out.printf("%5d", numbers[i][j]);
      }
      System.out.printf("\n");
    }
  }
  
  public static int[][] multiplication_table(int k)
  {
    if (k < 0)
    {
      return null;
    }
              
    int[][] result = new int[k+1][k+1];
    for (int i = 0; i <= k; i++)
    {
      for (int j = 0; j <= k; j++)
      {
        result[i][j] = i*j;
      }
    }
    
    return result;
  }
  
  public static void main(String[] args)
  {
    print_2d_array(multiplication_table(3));
  }
}

