import java.util.*;
import java.io.File;

public class problem6
{
  public static String[][] read_spreadsheet(String filename)
  {
    ArrayList<String> lines = read_file(filename);

    int rows = lines.size();

    // The row below creates an array of length "rows", that stores
    // objects of type String[]. Those objects are initialized to null.
    String[][] result = new String[rows][]; 

    for (int i = 0; i < lines.size(); i++)
    {
      String line = lines.get(i);
      String [] values = line.split(",");
      result[i] = values;
    }

    return result;
  } 
  
  
  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    ArrayList<String> result = new ArrayList<String>();

    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return result;
    }

    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    
    input_file.close();
    return result;
  }  
  
  
  public static double column_average(String[][] values, int col)
  {
    double column_sum = 0;
    double column_count = 0;
    for (int line = 0; line < values.length; line++)
    {
      String[] line_values = values[line];
      if (line_values.length <= col)
      {
        continue;
      }
      try
      {
        double value = Double.parseDouble(line_values[col]);
        column_sum += value;
        column_count++;
      }
      catch(Exception e)
      {
        continue;
      }

      if (column_count == 0)
      {
        return 0;
      }
    }
    return column_sum / column_count;

  }

          
  public static double largest_average(String filename)
  {
    String[][] values = read_spreadsheet(filename);
    
    double largest = 0;
    for (int col = 0; col < values[0].length; col++)
    {
      double current = column_average(values, col);
      if (current > largest)
      {
        largest = current;
      }
    }
        
    return largest;
  }


  public static void main(String[] args)
  {
    System.out.printf("%f\n", largest_average("file2.txt"));
  }
}

