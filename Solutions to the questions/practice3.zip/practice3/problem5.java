import java.util.*;
import java.io.File;

public class problem5
{
  public static String[][] read_spreadsheet(String filename)
  {
    ArrayList<String> lines = read_file(filename);

    int rows = lines.size();

    // The row below creates an array of length "rows", that stores
    // objects of type String[]. Those objects are initialized to null.
    String[][] result = new String[rows][]; 

    for (int i = 0; i < lines.size(); i++)
    {
      String line = lines.get(i);
      String [] values = line.split(",");
      result[i] = values;
    }

    return result;
  } 
  
  
  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    ArrayList<String> result = new ArrayList<String>();

    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return result;
    }

    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    
    input_file.close();
    return result;
  }  
  
  
  public static int count_equal(String filename, int col1, int col2)
  {
    String[][] values = read_spreadsheet(filename);
    int counter = 0;
    for (int line = 0; line < values.length; line++)
    {
      String[] line_values = values[line];
      if ((line_values.length <= col1) || (line_values.length <= col2))
      {
        continue;
      }
      if (line_values[col1].equals(line_values[col2]))
      {
        counter++;
      }
    }
    
    return counter;
  }


  public static void main(String[] args)
  {
    System.out.printf("count_equal(\"file1.txt\", 0,1) = %d\n", 
                      count_equal("file1.txt", 0,1));
    System.out.printf("count_equal(\"file1.txt\", 0,5) = %d\n", 
                      count_equal("file1.txt", 0,5));
    System.out.printf("count_equal(\"file1.txt\", 1,4) = %d\n", 
                      count_equal("file1.txt", 1,4));
    System.out.printf("count_equal(\"file1.txt\", 1,3) = %d\n", 
                      count_equal("file1.txt", 1,3));
  }
}

