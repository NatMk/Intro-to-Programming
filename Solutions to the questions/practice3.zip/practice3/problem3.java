public class problem3
{
  public static boolean check_sorted(int[] a)
  {
    if (a.length < 1)
    {
      return true;
    }
    for (int i = 1; i < a.length; i++)
    {
      if (a[i] < a[i-1])
      {
        return false;
      }
    }
    return true;
  }

          
  public static void main(String[] args)
  {
    int[] a1 = {20, 10, 20, 20, 20};
    boolean result = check_sorted(a1);
    System.out.printf("check_sorted(a1) = %b\n", result);

    int[] a2 = {1, 1, 1, 2};
    result = check_sorted(a2);
    System.out.printf("check_sorted(a2) = %b\n", result);
  }
}
