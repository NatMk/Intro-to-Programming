import java.io.File;
import java.util.*;

public class problem5
{
  public static void print_array_list(ArrayList<Integer> list)
  {
    for (int i = 0; i < list.size(); i++)
    {
      int current = list.get(i);
      System.out.printf("%d\n", current);
    }
  }  
  
  public static ArrayList<Integer> keep_large(ArrayList<Integer> list, int threshold)
  {
    ArrayList<Integer> result = new ArrayList();
    for (int i = 0; i < list.size(); i++)
    {
      int current = list.get(i);
      if (current >= threshold)
      {
        result.add(current);
      }
    }
    return result;
  }
  
  public static ArrayList<Integer> read_numbers(String filename)
  {
    ArrayList<String> lines = read_file(filename);
    ArrayList<Integer> result = new ArrayList();
    for (int i = 0; i < lines.size(); i++)
    {
      String current_line = lines.get(i);
      int current_int = Integer.parseInt(current_line);
      result.add(current_int);
    }
    
    return result;
  }

          
  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return null;
    }

    ArrayList<String> result = new ArrayList();
    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    input_file.close();
    
    return result;
  }  
  
  public static void main(String[] args)
  {
    String name1 = "numbers1.txt";
    ArrayList<Integer> numbers = read_numbers(name1);
    ArrayList<Integer> list2 = keep_large(numbers, 50);
    print_array_list(list2);
  }
}