import java.io.File;
import java.io.PrintWriter;
import java.util.*;

public class problem6
{
  public static void reverse_lines(String filename)
  {
    ArrayList<String> lines = read_file(filename);
    PrintWriter out = null;
    try
    {
      out = new PrintWriter(filename);
    } catch (Exception e)
    {
      System.out.printf("Error: failed to open file %s.\n", filename);
      System.exit(0);
    }
    
    for (int i = lines.size() - 1; i >= 0; i--)
    {
      String current = lines.get(i);
      out.printf("%s\r\n", current);
    }
    
    out.close();

  }

  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    try
    {
      input_file = new Scanner(temp);
    } catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
              filename);
      return null;
    }

    ArrayList<String> result = new ArrayList();
    while (input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    input_file.close();

    return result;
  }

  public static void main(String[] args)
  {
    String name1 = "in2.txt";
    reverse_lines(name1);
  }
}
