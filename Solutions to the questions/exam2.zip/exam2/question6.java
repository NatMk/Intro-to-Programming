public class question6
{
  public static String mix(String S1, String S2)
  {
    if (S1.length() != S2.length())
    {
      return "";
    }
    String result = "";
    for (int i = 0; i < S1.length(); i++)
    {
      result = result + S1.charAt(i) + S2.charAt(i);
    }
    return result;
  }

  public static void main(String[] args)
  {
    System.out.printf("mix(\"abcd\", \"1234\") = %s\n", 
                      mix("abcd", "1234"));
    System.out.printf("mix(\"aaa\", \"bbb\") = %s\n", 
                      mix("aaa", "bbb"));
    System.out.printf("mix(\"hello\", \"world\") = %s\n", 
                      mix("hello", "world"));
    System.out.printf("mix(\"cat\", \"hat\") = %s\n", 
                      mix("cat", "hat"));
  }
}
