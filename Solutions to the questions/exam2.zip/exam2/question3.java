public class question3
{
  public static boolean check_name(String name)
  {
    if ((name.length() < 4) || (name.length() > 8))
    {
      return false;
    }
    if (name.charAt(0) != 'T')
    {
      return false;
    }
    String legal = "TYRAN";
    for (int i = 1; i < name.length(); i++)
    {
      char c = name.charAt(i);
      if (legal.indexOf(c) == -1)
      {
        return false;
      }
    }
    return true;
  }

  public static void main(String[] args)
  {
    System.out.printf("check_name(\"GEORGE\") = %b\n", check_name("GEORGE"));
    System.out.printf("check_name(\"TAN\") = %b\n", check_name("TAN"));
    System.out.printf("check_name(\"ARAN\") = %b\n", check_name("ARAN"));
    System.out.printf("check_name(\"TARAN\") = %b\n", check_name("TARAN"));
  }
}
