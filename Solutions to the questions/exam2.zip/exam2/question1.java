public class question1
{
  public static int foo(int a, int b, int c)
  {
    System.out.printf("1: a = %d\n", a);
    System.out.printf("2: b = %d\n", b);
    System.out.printf("3: c = %d\n", c);
    a = 2*a;
    b = c;
    c = a - 1;
    System.out.printf("4: a = %d\n", a);
    System.out.printf("5: b = %d\n", b);
    System.out.printf("6: c = %d\n", c);
    return a+b+c;
  }

  public static void main(String[] args)
  {
    int a = 3;
    int b = 4;
    int c = 1;
    c = foo(b, a, c);
    System.out.printf("7: a = %d\n", a);
    System.out.printf("8: b = %d\n", b);
    System.out.printf("9: c = %d\n", c);
  }
}
