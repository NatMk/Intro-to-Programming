public class question5
{
  public static String pick_odd_positions(String name)
  {
    String result = "";
    for (int i = 1; i < name.length(); i += 2)
    {
      char c = name.charAt(i);
      result = result + c;
    }
    return result;
  }

  public static void main(String[] args)
  {
    System.out.printf("pick_odd_positions(\"hello\") = %s\n", 
                      pick_odd_positions("hello"));
    System.out.printf("pick_odd_positions(\"Arlington\") = %s\n", 
                      pick_odd_positions("Arlington"));
    System.out.printf("pick_odd_positions(\"television\") = %s\n", 
                      pick_odd_positions("television"));
    System.out.printf("pick_odd_positions(\"h\") = %s\n", 
                      pick_odd_positions("h"));
    System.out.printf("pick_odd_positions(\"hhhhh\") = %s\n", 
                      pick_odd_positions("hhhhh"));
  }
}
