public class question4
{
  public static int foo(int number)
  {
    for (int A = 0; A <= number; A++)
    {
      if (number == A*A*3 + 4)
      {
        return A;
      }
    }
    return -1;
  }

  public static void main(String[] args)
  {
    System.out.printf("foo(4) = %d\n", foo(4));
    System.out.printf("foo(7) = %d\n", foo(7));
    System.out.printf("foo(16) = %d\n", foo(16));
    System.out.printf("foo(30004) = %d\n", foo(30004));
    System.out.printf("foo(1) = %d\n", foo(1));
    System.out.printf("foo(10) = %d\n", foo(10));
  }
}
