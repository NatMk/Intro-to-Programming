public class question2
{
  public static int foo(int a, int b)
  {
    if ((a == 7) || (b == 2))
    {
      return 1;
    }
    if ((a == 7) && (b == 7))
    {
      return 2;
    }
    int result = 0;
    for (int i = a; i <= b; i++)
    {
      result = result + i;
    }
    return result;
  }

  public static void main(String[] args)
  {
    System.out.printf("foo(6, 7) = %d\n", foo(6, 7));
    System.out.printf("foo(1, 2) = %d\n", foo(1, 2));
    System.out.printf("foo(7, 7) = %d\n", foo(7, 7));
    System.out.printf("foo(6, 4) = %d\n", foo(6, 4));
  }
}
