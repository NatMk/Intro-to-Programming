public class problem4
{
  public static boolean check_letters(String A, String B)
  {
    for (int i = 0; i < B.length(); i++)
    {
      if (A.indexOf(B.charAt(i)) == -1)
      {
        return false;
      }
    }
    return true;
  }

  public static void main(String[] args)
  {
    System.out.printf("check_letters(\"this is a test\", \"asteh\") = %b\n", 
                      check_letters("this is a test", "asteh"));
    System.out.printf("check_letters(\"THIS IS a test\", \"asteh\") = %b\n", 
                      check_letters("THIS IS a test", "asteh"));
  
  }
}
