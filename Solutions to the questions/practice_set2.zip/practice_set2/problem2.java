public class problem2
{
  public static void print_special(String s)
  {
    for (int i = 0; i < s.length(); i++)
    {
      for (int j = 0; j <= i; j++)
      {
        System.out.printf("%c", s.charAt(i));
      }
      System.out.printf("\n");
    }
  }

  public static void main(String[] args)
  {
    print_special("Texas");
  
  }
}
