
import java.io.PrintWriter;

public class problem3
{
  public static void print_special_to_file(String s, String output_file)
  {
    // open the file for writing, create a PrintWriter object
    PrintWriter out = null;
    try
    {
      out = new PrintWriter(output_file);
    } catch (Exception e)
    {
      System.out.printf("Error: failed to open file %s.\n", output_file);
      System.exit(0);
    }
    
    // write the require text to the file.
    for (int i = 0; i < s.length(); i++)
    {
      for (int j = 0; j <= i; j++)
      {
        out.printf("%c", s.charAt(i));
      }
      out.printf("\r\n");
    }

    // close the file
    out.close();
  }

  public static void main(String[] args)
  {
    print_special_to_file("Texas", "target.txt");
    System.out.printf("Exiting...\n");
  }
}
