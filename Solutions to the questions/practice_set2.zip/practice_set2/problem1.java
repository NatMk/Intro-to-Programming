public class problem1
{
  public static int foo(int A, int B)
  {
    if (A > B)
    {
      return -1;
    }
    
    int counter = 0;
    for (int i = A; i <= B; i++)
    {
      counter += i;
    }
    
    return counter;
  }

  public static void main(String[] args)
  {
    System.out.printf("foo(5, 9) = %d\n", foo(5, 9));
    System.out.printf("foo(5, 3) = %d\n", foo(5, 3));
    System.out.printf("foo(5, 5) = %d\n", foo(5, 5));
  }
}
