import java.io.File;
import java.util.*;


public class problem6
{
  public static boolean check_ab(String S)
  {
    int a_counter = 0;
    int b_counter = 0;
    for (int i = 0; i < S.length(); i++)
    {
      if ((S.charAt(i) == 'a') || (S.charAt(i) == 'A'))
      {
        a_counter++;
      }
      if ((S.charAt(i) == 'b') || (S.charAt(i) == 'B'))
      {
        b_counter++;
      }
    }
    return (a_counter == b_counter);
  }

  
  public static boolean check_ab_in_file(String filename)
  {
    ArrayList<String> lines = read_file(filename);
    String text = "";
    for (int i = 0; i < lines.size(); i++)
    {
      text = text + lines.get(i);
    }
    boolean result = check_ab(text);
    return result;
  }

  
  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return null;
    }

    ArrayList<String> result = new ArrayList();
    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    input_file.close();
    
    return result;
  }  
  
  
  public static void main(String[] args)
  {
    boolean result = check_ab_in_file("text1.txt");
    System.out.printf("check_ab_in_file(\"text1.txt\") = %b\n", result);
    result = check_ab_in_file("text2.txt");
    System.out.printf("check_ab_in_file(\"text2.txt\") = %b\n", result);
  }
}
