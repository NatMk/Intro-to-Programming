import java.util.*;


public class problem8
{
  public static int[] subarray_sums(int[][] items)
  {
    int[] result = new int[items.length];
    
    for (int i = 0; i < items.length; i++)
    {
      int sum = 0;
      for (int j = 0; j < items[i].length; j++)
      {
        sum = sum + items[i][j];
      }
      result[i] = sum;
    }
    return result;
  }
  
  
  public static void print_array(int[] numbers)
  {
    System.out.printf("{%d", numbers[0]);
    for (int i = 1; i < numbers.length; i++)
    {
      System.out.printf(", %d", numbers[i]);
    }
    System.out.printf("}\n");
  }
  
  
  public static void main(String[] args)
  {
    int[][] input = {{10, 5, 3}, {3, 1}};
    int[] result = subarray_sums(input);
    System.out.printf("subarray_sums({{10, 5, 3}, {3, 1}} = ");
    print_array(result);
  }
}
