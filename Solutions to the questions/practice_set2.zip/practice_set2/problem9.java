public class problem9
{
  public static int[] pick_elements(int[] numbers, int[] positions)
  {
    int[] result = new int[positions.length];
    for (int i = 0; i < positions.length; i++)
    {
      result[i] = numbers[positions[i]];
    }
    return result;
  }
  
  public static void print_array(int[] numbers)
  {
    System.out.printf("{%d", numbers[0]);
    for (int i = 1; i < numbers.length; i++)
    {
      System.out.printf(", %d", numbers[i]);
    }
    System.out.printf("}\n");
  }
  
  
  public static void main(String[] args)
  {
    int[] numbers = {10, 5, 3, 20, 30};
    int[] positions = {3, 1};
    System.out.printf("pick_elements({10, 5, 3, 20, 30}, {3, 1}) = ");
    print_array(pick_elements(numbers, positions));
    
    int[] numbers2 = {10, 5, 3, 20, 30};
    int[] positions2 = {0, 4, 1};
    System.out.printf("pick_elements({10, 5, 3, 20, 30}, {0, 4, 1}) = ");
    print_array(pick_elements(numbers2, positions2));
  }
}
