public class problem5
{
  public static boolean check_ab(String S)
  {
    int a_counter = 0;
    int b_counter = 0;
    for (int i = 0; i < S.length(); i++)
    {
      if ((S.charAt(i) == 'a') || (S.charAt(i) == 'A'))
      {
        a_counter++;
      }
      if ((S.charAt(i) == 'b') || (S.charAt(i) == 'B'))
      {
        b_counter++;
      }
    }
    return (a_counter == b_counter);
  }

  public static void main(String[] args)
  {
    System.out.printf("check_ab(\"hello\") = %b\n", 
                      check_ab("hello"));
    System.out.printf("check_ab(\"cat\") = %b\n", 
                      check_ab("cat"));
    System.out.printf("check_ab(\"Barbados\") = %b\n", 
                      check_ab("Barbados"));
    System.out.printf("check_ab(\"ALL BREAD and butter\") = %b\n", 
                      check_ab("ALL BREAD and butter"));
  
  }
}
