public class problem10
{
  public static int[] insert(int[] numbers, int position, int value)
  {
    int[] result = new int[numbers.length + 1];
    
    for (int i = 0; i < position; i++)
    {
      result[i] = numbers[i];
    }

    result[position] = value;
    for (int i = position; i < numbers.length; i++)
    {
      result[i+1] = numbers[i];
    }
    return result;
  }
  
  public static void print_array(int[] numbers)
  {
    System.out.printf("{%d", numbers[0]);
    for (int i = 1; i < numbers.length; i++)
    {
      System.out.printf(", %d", numbers[i]);
    }
    System.out.printf("}\n");
  }
  
  
  public static void main(String[] args)
  {
    int[] numbers = {10, 5, 3, 20, 30};
    System.out.printf("insert({10, 5, 3, 20, 30}, 0, 11) = ");
    print_array(insert(numbers, 0, 11));
    
    System.out.printf("insert({10, 5, 3, 20, 30}, 4, 11) = ");
    print_array(insert(numbers, 4, 11));
  }
}
