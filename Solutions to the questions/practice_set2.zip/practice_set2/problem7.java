public class problem7
{
  public static int find_N(int number)
  {
    int N = 0;
    while(true)
    {
      int current = (int) (Math.pow(2.0, N) + Math.pow(3.0, N));
      if (current > number)
      {
        return -1;
      }
      if (current == number)
      {
        return N;
      }
      N++;
    }
  }

  public static void main(String[] args)
  {
    System.out.printf("find_N(2) = %d\n", find_N(2));
    System.out.printf("find_N(4) = %d\n", find_N(4));
    System.out.printf("find_N(5) = %d\n", find_N(5));
    System.out.printf("find_N(10) = %d\n", find_N(10));
    System.out.printf("find_N(13) = %d\n", find_N(13));
  }
}
