public class task2
{
  public static String most_rs(String[] strings)
  {
    String result = strings[0];
    int max_rs = count_rs(strings[0]);
    for (int i = 1; i < strings.length; i++)
    {
      int rs = count_rs(strings[i]);
      if (rs > max_rs)
      {
        max_rs = rs;
        result = strings[i];
      }
    }
    return result;
  }
  
  public static int count_rs(String s)
  {
    int result = 0;
    for (int i = 0; i < s.length(); i++)
    {
      if ("Rr".indexOf(s.charAt(i)) >= 0)
      {
        result++;
      }
    }
    return result;
  }
  
    
  public static void main(String[] args)
  {
    String[] a = {"February", "ROAR", "winter"};
    System.out.printf("most_rs({\"February\", \"ROAR\", \"winter\") = %s\n",
                      most_rs(a));
    
    String[] b = {"miRRor", "train", "treasure", "carry"};
    System.out.printf("most_rs({\"miRRor\", \"train\", \"treasure\", \"carry\") = %s\n",
                      most_rs(b));
    
  }
}
