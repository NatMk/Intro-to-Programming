public class task7
{
  public static boolean check_subset(int[] values, int[] set)
  {
    for (int i = 0; i < values.length; i++)
    {
      boolean found = false;
      for (int j = 0; j < set.length; j++)
      {
        if (values[i] == set[j])
        {
          found = true;
        }
      }
      if (found == false)
      {
        return false;
      }
    }
    return true;
  }
  
  public static void print_array(int[] numbers)
  {
    System.out.printf("{%d", numbers[0]);
    for (int i = 1; i < numbers.length; i++)
    {
      System.out.printf(", %d", numbers[i]);
    }
    System.out.printf("}\n");
  }
  
  
  public static void main(String[] args)
  {
    int[] values = {11, 30};
    int[] set = {2, 0, 30, 11, 30, 5};
    System.out.printf("check_subset({11, 30}, {2, 0, 30, 11, 30, 5}) = %b\n", 
                      check_subset(values, set));

    int[] values2 = {30};
    int[] set2 = {2, 0, 30, 11, 30, 5};
    System.out.printf("check_subset({30}, {2, 0, 30, 11, 30, 5}) = %b\n", 
                      check_subset(values2, set2));

    int[] values3 = {30, 11, 10, 0};
    int[] set3 = {2, 0, 30, 11, 30, 5};
    System.out.printf("check_subset({30, 11, 10, 0}, {2, 0, 30, 11, 30, 5}) = %b\n", 
                      check_subset(values3, set3));
    
  }
}
