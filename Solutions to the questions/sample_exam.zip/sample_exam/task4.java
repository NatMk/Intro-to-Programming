public class task4
{
  public static int find_position(int[] numbers)
  {
    for (int i = 0; i < numbers.length; i++)
    {
      if (numbers[i] > 100)
      {
        return i;
      }
    }
    return -1;
  }
  
  public static void print_array(int[] numbers)
  {
    System.out.printf("{%d", numbers[0]);
    for (int i = 1; i < numbers.length; i++)
    {
      System.out.printf(", %d", numbers[i]);
    }
    System.out.printf("}\n");
  }
  
  
  public static void main(String[] args)
  {
    int[] a = {10, 30, 200, 20};
    System.out.printf("find_position({10, 30, 200, 20}) = %d\n",
                      find_position(a));
    
    int[] b = {10, 30, 20, 10, 200, 20, 415};
    System.out.printf("find_position({10, 30, 20, 10, 200, 20, 415}) = %d\n",
                      find_position(b));
    
    int[] c = {10, 30, 20};
    System.out.printf("find_position({10, 30, 20}) = %d\n",
                      find_position(c));
    
  }
}
