public class task5
{
  public static int sum_odd_numbers(int[] numbers)
  {
    int result = 0;
    for (int i = 0; i < numbers.length; i++)
    {
      if (numbers[i] % 2 == 1)
      {
        result += numbers[i];
      }
    }
    return result;
  }
  
  public static void print_array(int[] numbers)
  {
    System.out.printf("{%d", numbers[0]);
    for (int i = 1; i < numbers.length; i++)
    {
      System.out.printf(", %d", numbers[i]);
    }
    System.out.printf("}\n");
  }
  
  
  public static void main(String[] args)
  {
    int[] a = {11, 30, 5, 3};
    System.out.printf("sum_odd_numbers({11, 30, 5, 3}) = %d\n",
                      sum_odd_numbers(a));

    int[] b = {1, 5, 5, 2, 2, 1};
    System.out.printf("sum_odd_numbers({1, 5, 5, 2, 2, 1}) = %d\n",
                      sum_odd_numbers(b));
  }
}
