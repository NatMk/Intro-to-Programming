public class task6
{
  public static int[] select_numbers(int[] numbers, int[] positions)
  {
    int[] result = new int[positions.length];
    for (int i = 0; i < positions.length; i++)
    {
      result[i] = numbers[positions[i]];
    }
    return result;
  }
  
  public static void print_array(int[] numbers)
  {
    System.out.printf("{%d", numbers[0]);
    for (int i = 1; i < numbers.length; i++)
    {
      System.out.printf(", %d", numbers[i]);
    }
    System.out.printf("}\n");
  }
  
  
  public static void main(String[] args)
  {
    int[] numbers = {11, 30, 5, 3};
    int[] positions = {2, 0};
    System.out.printf("select_numbers({11, 30, 5, 3}, {2, 0}) = ");
    print_array(select_numbers(numbers, positions));
    
    int[] numbers2 = {11, 30, 5, 3};
    int[] positions2 = {1, 0, 1, 2};
    System.out.printf("select_numbers({11, 30, 5, 3}, {1, 0, 1, 2}) = ");
    print_array(select_numbers(numbers2, positions2));
  }
}
