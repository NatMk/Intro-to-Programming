public class task1
{
  public static int[] reverse_array(int[] numbers)
  {
    int[] result = new int[numbers.length];
    for (int i = 0; i < numbers.length; i++)
    {
      result[i] = numbers[numbers.length - i - 1];
    }
    return result;
  }
  
  public static void print_array(int[] numbers)
  {
    System.out.printf("{%d", numbers[0]);
    for (int i = 1; i < numbers.length; i++)
    {
      System.out.printf(", %d", numbers[i]);
    }
    System.out.printf("}\n");
  }
  
  
  public static void main(String[] args)
  {
    int[] a = {10, 20, 30, 15, 25};
    System.out.printf("reverse_array({10, 20, 30, 15, 25}) = ");
    print_array(reverse_array(a));

    int[] b = {10, 3, 2};
    System.out.printf("reverse_array({10, 3, 2}) = ");
    print_array(reverse_array(b));
    
  }
}
