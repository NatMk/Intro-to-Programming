import java.util.*;
import java.io.File;


public class task3
{
  static int[] column_sums(String filename)
  {
    String[][] data = read_spreadsheet(filename);
    int[] result = new int[data[0].length];
    
    for (int row = 0; row < data.length; row++)
    {
      for (int col = 0; col < data[0].length; col++)
      {
        result[col] += Integer.parseInt(data[row][col]);
      }
    }
    return result;
  }
  
  
  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return null;
    }

    ArrayList<String> result = new ArrayList<String>();
    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    
    input_file.close();
    return result;
  } 


  public static String[][] read_spreadsheet(String filename)
  {
    ArrayList<String> lines = read_file(filename);
    
    int rows = lines.size();

    // The row below creates an array of length "rows", that stores
    // objects of type String[]. Those objects are initialized to null.
    String[][] result = new String[rows][]; 
            
    for (int i = 0; i < lines.size(); i++)
    {
      String line = lines.get(i);
      String [] values = line.split(",");
      result[i] = values;
    }

    return result;
  }  
  
  
  public static void print_array(int[] numbers)
  {
    System.out.printf("{%d", numbers[0]);
    for (int i = 1; i < numbers.length; i++)
    {
      System.out.printf(", %d", numbers[i]);
    }
    System.out.printf("}\n");
  }
  
  
    public static void main(String[] args)
  {
    System.out.printf("column_sums(\"hello.txt\") = ");
    print_array(column_sums("hello.txt"));
  }

  
}
