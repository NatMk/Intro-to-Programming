import java.util.Scanner;

public class task6b
{
  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("When is the first Sunday this March? ");
    int day = in.nextInt();
    
    if ((day < 1) || (day > 7))
    {
      System.out.printf("invalid entry\n");      
    }
    else
    {
      System.out.printf("This March, Sundays fall on:\n");    
      for (int i = day; i <= 31; i+=7)
      {
        System.out.printf("March %d\n", i);      
      }
    }
  }
}