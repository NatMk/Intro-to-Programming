import java.util.Scanner;

public class task5
{

  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Enter a word: ");
    String word = in.next();
    String vowels = "aeoiuAEIOU";
    
    int counter = 0;
    while(counter < word.length())
    {
      char current = word.charAt(counter);
      if (vowels.indexOf(current) == -1)
      {
        System.out.printf("%c", current);
      }
      counter++;
    }
    System.out.printf("\nExiting...\n");
  }
}