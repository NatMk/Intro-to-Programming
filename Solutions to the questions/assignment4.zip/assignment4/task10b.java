import java.util.Scanner;

public class task10b
{

  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);

    System.out.printf("Enter an integer M: ");
    int M = in.nextInt();

    System.out.printf("Enter an integer N: ");
    int N = in.nextInt();

    int counter = 0;
    
    for (int i = M; i <= N; i++)
    {
      if (i % 11 == 0)
      {
        counter++;
      }
    }

    System.out.printf("%d numbers between %d and %d are multiples of 11.\n",
                      counter, M, N);
    System.out.printf("Exiting...\n");
  }
}