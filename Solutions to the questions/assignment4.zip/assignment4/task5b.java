import java.util.Scanner;

public class task5b
{

  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Enter a word: ");
    String word = in.next();
    String vowels = "aeoiuAEIOU";
    for (int counter = 0; counter < word.length(); counter++)
    {
      char current = word.charAt(counter);
      if (vowels.indexOf(current) == -1)
      {
        System.out.printf("%c", current);
      }
    }
    System.out.printf("\nExiting...\n");
  }
}