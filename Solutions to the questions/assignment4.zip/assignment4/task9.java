import java.util.Scanner;

public class task9
{

  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Enter a positive integer N > 0: ");
    
    int N = in.nextInt();
    if (N < 0)
    {
      System.out.printf("Exiting...\n");
      System.exit(0);
    }
    
    String stars = "*";
    
    int i = 1;
    while(i <= N)
    {
      System.out.printf("%s\n", stars);
      stars = stars + "*";
      i++;
    }
    System.out.printf("Exiting...\n");
  }
}