import java.util.Scanner;

public class task4b
{

  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Enter an integer N: ");
    int N = in.nextInt();
    boolean is_holy = false;
    for (int i = 2; i < N; i++)
    {
      int value = i*i + i;
      if (N == value)
      {
        is_holy = true;
        break;
      }
    }
    if (is_holy)
    {
      System.out.printf("%d is a holy number in Numerion.\n", N);
    } 
    else
    {
      System.out.printf("%d is not a holy number in Numerion.\n", N);
    }
    System.out.printf("Exiting...\n");
  }
}
