import java.util.Scanner;

public class task8b
{
  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Enter a positive integer N > 0: ");
    
    int N = in.nextInt();
    if (N <= 0)
    {
      System.out.printf("Exiting...\n");
      System.exit(0);
    }
    for (int i = 1; i <= 40000; i = i * N)
    {
      System.out.printf("%d\n", i);
    }
    System.out.printf("Exiting...\n");
  }
}