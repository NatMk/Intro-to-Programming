import java.util.Scanner;

public class task8
{

  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Enter a positive integer N > 0: ");
    
    int N = in.nextInt();
    if (N <= 0)
    {
      System.out.printf("Exiting...\n");
      System.exit(0);
    }
    
    int i = 1;
    while(i <= 40000)
    {
      System.out.printf("%d\n", i);
      i = i * N;
    }
    System.out.printf("Exiting...\n");
  }
}