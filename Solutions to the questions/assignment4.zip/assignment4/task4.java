import java.util.Scanner;

public class task4
{

  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Enter an integer N: ");
    int N = in.nextInt();
    boolean is_holy = false;
    int i = 2;
    while(i < N)
    {
      int value = i*i + i;
      if (N == value)
      {
        is_holy = true;
      }
      i++;
    }
    if (is_holy)
    {
      System.out.printf("%d is a holy number in Numerion.\n", N);
    } 
    else
    {
      System.out.printf("%d is not a holy number in Numerion.\n", N);
    }
    System.out.printf("Exiting...\n");
  }
}