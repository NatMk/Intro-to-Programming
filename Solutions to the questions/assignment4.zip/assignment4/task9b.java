import java.util.Scanner;

public class task9b
{
  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);
    System.out.printf("Enter a positive integer N > 0: ");
    
    int N = in.nextInt();
    if (N < 0)
    {
      System.out.printf("Exiting...\n");
      System.exit(0);
    }
    for (int i = 1; i <= N; i++)
    {
      for (int j = 1; j <= i; j++)
      {
        System.out.printf("*");
      }
      System.out.printf("\n");
    }
    System.out.printf("Exiting...\n");
  }
}
