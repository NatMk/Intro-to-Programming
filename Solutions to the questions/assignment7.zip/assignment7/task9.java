public class task9
{
  public static double[][] matrix_min(double[][] x, double[][] y)
  {
    int rows = x.length;
    int cols = x[0].length;
    
    // make sure the two matrices have the same size
    if ((rows != y.length) || (cols != y[0].length))
    {
      return null;
    }
    
    double[][] result = new double[rows][cols];
    
    for (int i = 0; i < x.length; i++)
    {
      for (int j = 0; j < x[i].length; j++)
      {
        if (x[i][j] < y[i][j])
        {
          result[i][j] = x[i][j];
        }
        else
        {
          result[i][j] = y[i][j];
        }
      }
    }
    
    return result;
  }
  
  public static void print_double_matrix(String name, double[][] a)
  {
    if (a == null)
    {
      System.out.printf("%s: null\n", name);    
      return;
    }
    System.out.printf("%s:\n", name);    
    for (int i = 0; i < a.length; i++)
    {
      for (int j = 0; j < a[i].length; j++)
      {
        System.out.printf("%7.1f", a[i][j]);
      }
      System.out.printf("\n");
    }
    System.out.printf("\n");
  }
  
  
  public static void main(String[] args)
  {
    double[][] a = { {3.2, 2.1, 5.3},
                     {8.0, 4.9, 5.7} };
    double[][] b = { {1.1, 2.2, 3.3}, 
                     {4.4, 5.5, 6.6} };
      
    double[][] result = matrix_min(a, b);
    print_double_matrix("a", a);
    print_double_matrix("b", b);
    print_double_matrix("result", result);
  }
}
