public class problem3
{
  public static int[] all_positions(int[] array, int value)
  {
    int count = 0;
    
    for (int i = 0; i < array.length; i++)
    {
      if (array[i] == value)
      {
        count++;
      }
    }
    int[] result = new int[count];
    int index = 0;
    for (int i = 0; i < array.length; i++)
    {
      if (array[i] == value)
      {
        result[index] = i;
        index++;
      }
    }
    
    return result;
  }

  public static void print_array(int[] numbers)
  {
    if (numbers.length == 0)
    {
      System.out.printf("{}\n");
      return;
    }
    System.out.printf("{%d", numbers[0]);
    for (int i = 1; i < numbers.length; i++)
    {
      System.out.printf(", %d", numbers[i]);
    }
    System.out.printf("}\n");
  }
  
  
  public static void main(String[] args)
  {
    int[] a1 = {5, 20, 20, 10, 40, 20};
    int[] result = all_positions(a1, 20);
    System.out.printf("all_positions(a1, 20) = ");
    print_array(result);

    int[] a2 = {1, 1, 1, 2};
    result = all_positions(a2, 2);
    System.out.printf("check_all_equal(a2, 2) = ");
    print_array(result);
  }
}
