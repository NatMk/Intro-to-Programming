public class problem2
{
  public static boolean check_all_equal(int[] a)
  {
    if (a.length == 0)
    {
      return true;
    }
    for (int i = 1; i < a.length; i++)
    {
      if (a[i] != a[0])
      {
        return false;
      }
    }
    return true;
  }

          
  public static void main(String[] args)
  {
    int[] a1 = {20, 20, 20, 20, 20};
    boolean result = check_all_equal(a1);
    System.out.printf("check_all_equal(a1) = %b\n", result);

    int[] a2 = {1, 1, 1, 2};
    result = check_all_equal(a2);
    System.out.printf("check_all_equal(a2) = %b\n", result);
  }
}
