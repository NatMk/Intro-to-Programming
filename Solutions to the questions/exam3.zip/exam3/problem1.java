import java.util.*;
import java.io.File;

public class problem1
{
  public static void print_email_provider(String filename)
  {
    ArrayList<String> lines = read_file(filename);
    for (int i = 0; i < lines.size(); i++)
    {
      String line = lines.get(i);
      String[] fields = line.split("[@.]");
      int number = fields.length;
      String provider = fields[number-2];
      System.out.printf("address: %s, provider: %s\n", line, provider);
    }
  }
  
  
  public static ArrayList<String> read_file(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;
    ArrayList<String> result = new ArrayList<String>();

    try
    {
      input_file = new Scanner(temp);
    }
    catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
                        filename);
      return result;
    }

    while(input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }
    
    input_file.close();
    return result;
  }  
  
  
    public static void main(String[] args)
  {
    String filename = "file1.txt";
    print_email_provider(filename);
  }
}
