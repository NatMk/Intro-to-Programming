import java.util.*;

public class problem4
{
  public static ArrayList<String> select_strings(ArrayList<String> strings)
  {
    ArrayList<String> result = new ArrayList<String>();
    
    for (int i = 0; i < strings.size(); i++)
    {
      String current = strings.get(i);
      for (int j = 0; j < current.length(); j++)
      {
        char c = current.charAt(j);
        if ("0123456789".indexOf(c) > -1)
        {
          result.add(current);
          break;
        }
      }
    }
    
    return result;
  }


  public static ArrayList<String> array_to_list(String[] a)
  {
    // create empty list
    ArrayList<String> result = new ArrayList();
    
    // loop through array elements
    for (int i = 0; i < a.length; i++)
    {
    //    add each element to the list
      String current = a[i];
      result.add(current);
    }
    
    return result;
  }
  
  
  public static void print_list(ArrayList<String> list)
  {
    if (list.size() == 0)
    {
      System.out.printf("[]\n");
      return;
    }
    System.out.printf("[%s", list.get(0));
    for (int i = 1; i < list.size(); i++)
    {
      System.out.printf(", %s", list.get(i));
    }
    System.out.printf("}\n");
  }
  
  
  public static void main(String[] args)
  {
    String[] a1 = {"hello", "123", "a7z", "az"};
    ArrayList<String> list1 = array_to_list(a1);
    ArrayList<String> result1 = select_strings(list1);
    System.out.printf("select_strings(list1) = ");
    print_list(result1);

    String[] a2 = {"hello", "az"};
    ArrayList<String> list2 = array_to_list(a2);
    ArrayList<String> result2 = select_strings(list2);
    System.out.printf("select_strings(list2) = ");
    print_list(result2);
  }
}
