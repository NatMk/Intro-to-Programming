public class problem5
{
  public static int most_frequent(int[] array)
  {
    int max_count = 0;
    int max_value = 0;
    
    for (int i = 0; i < array.length; i++)
    {
      int count = 0;
      int value = array[i];
      for (int j = 0; j < array.length; j++)
      {
        if (array[j] == value)
        {
          count++;
        }
      }
      if (count > max_count)
      {
        max_count = count;
        max_value = value;
      }
    }
    return max_value;
  }

  
  public static void main(String[] args)
  {
    int[] a1 = {5, 20, 10, 40, 20};
    int result1 = most_frequent(a1);
    System.out.printf("most_frequent(a1) = %d\n", result1);

    int[] a2 = {2, 2, 1, 2, 1, 1, 1};
    int result2 = most_frequent(a2);
    System.out.printf("most_frequent(a2) = %d\n", result2);

  }
}
